from tkinter import CASCADE
from django.db import models
import datetime

# Create your models here.

class Category(models.Model):
    Category = models.CharField(max_length=50)

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

    def __str__(self):
        return self.Category

class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    description = models.CharField(max_length=200, default=' ')
    image = models.ImageField(upload_to = 'uploads/product/')
    category = models.ForeignKey(Category, on_delete = models.CASCADE, default = 1)

    @staticmethod
    def get_all_products():
        return Product.objects.all()

    @staticmethod
    def get_product_by_id(category_id):
        if category_id:
            return Product.objects.filter(category = category_id)
        else:
            return Product.objects.all()

    @staticmethod
    def get_product_in_cart(ids):
        return Product.objects.filter(id__in = ids)

class Customer(models.Model):
    customer_name = models.CharField(max_length = 50)
    phone_number = models.CharField(max_length = 15)
    email = models.EmailField()
    password = models.CharField(max_length=50)

    def register(self):
        self.save()

    def get_customer_by_email(email):
        return Customer.objects.get(email = email)

    def isExists(self):
        if Customer.objects.filter(email = self.email):
            return True
        return False

class Order(models.Model):
    product = models.ForeignKey(Product, on_delete = models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete = models.CASCADE)
    quantity = models.IntegerField(default = 1)
    price = models.IntegerField()
    date = models.DateField(default = datetime.datetime.today)
    status = models.CharField(max_length = 50, default = "Pending")

    def register(self):
        self.save()

    def get_order_by_customer(customer):
        return Order.objects.filter(customer = customer).order_by('-date')