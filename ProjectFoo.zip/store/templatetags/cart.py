from django import template

register = template.Library()

@register.filter(name = 'is_in_cart')
def is_in_cart(product, cart):
    #print("cart value in filter = ",cart)
    keys = cart.keys()
    for id in keys:
        if id == str(product.id):
            return True

    return False

@register.filter(name = 'cart_quantity')
def cart_quantity(product, cart):
    keys = cart.keys()
    for id in keys:
        #print("id to be tested ===== ",id)
        if id == str(product.id):
            return cart.get(id)
    return 0

@register.filter(name = 'total_product_price')
def total_product_price(product, cart):
    return cart_quantity(product, cart) * product.price

@register.filter(name = 'total_price')
def total_price(products, cart):
    sum = 0
    for product in products:
        sum += total_product_price(product, cart)
    return sum
