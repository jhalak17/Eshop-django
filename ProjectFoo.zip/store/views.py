from django.shortcuts import render, redirect, HttpResponseRedirect
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from .models import Product, Category, Customer, Order
from django.views import View
from .middleware import auth_middleware
from django.utils.decorators import method_decorator
import razorpay
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest


# Create your views here.
class Index(View):
    def get(self, request):
        cart = request.session.get('cart')
        print("This is cart in index ",cart)
        if not cart:
            request.session['cart'] = {}
        products = Product.get_all_products()
        categories = Category.get_all_categories()
        data = {}
        data["products"] = products
        data["categories"] = categories
        print("This is for filtering product acc category = ", request.GET)
        #print(request.session.get('customer'))
        category_id = request.GET.get('category')
        if category_id:
            products = Product.get_product_by_id(category_id)
            print("products after filteration ",products)
        else:
            products = Product.get_all_products()
        data["products"] = products
        return render(request, 'index.html', data)

    def post(self, request):
        product_id = request.POST.get("product_id")
        print("The product id from cart is =", product_id)
        remove = request.POST.get("reduce")
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product_id)
            if quantity:
                if remove == 'True':
                    if quantity == 1:
                        cart.pop(product_id)
                    else:
                        cart[product_id] = quantity - 1
                else:
                    cart[product_id] = quantity + 1
            else:
                cart[product_id] = 1
        else:
            cart = {}
            cart[product_id] = 1
        request.session['cart'] = cart
        print("Cart == ",request.session['cart'])
        return redirect("homepage")
    

def show_signup(request):
    print(request.method)
    if request.method == "GET":
        return render(request, 'signup.html')
    else:
        customer_name = request.POST.get("name")
        email = request.POST.get("email")
        phone_number = request.POST.get("phone")
        password = request.POST.get("password")
        error_message = None
        if len(password) < 8:
            error_message = "Length should be greater than 8 !!"
        customer = Customer(customer_name = customer_name, email = email, phone_number = phone_number, password = password)

        if customer.isExists():
            error_message = ' Customer already exists !!!!'
        
        if error_message:
            return render(request, 'signup.html', {'error' : error_message})
        else:
            customer.register()
            return redirect('homepage')

class Login(View):
    return_url = None
    def get(self,request):
        Login.return_url = request.GET.get('return_url')
        print("get login ",Login.return_url)
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get("email")
        password = request.POST.get("password")
        customer = Customer.get_customer_by_email(email)
        print(customer.email, customer.password)
        error_message = None
        if customer:
            if password == customer.password:
                request.session['customer'] = customer.id
                if Login.return_url:
                    print(Login.return_url)
                    return HttpResponseRedirect(Login.return_url)
                else:
                    return_url = None
                    return redirect('homepage')
            else:
                error_message = "Invalid Email or Password"
        else:
            error_message = "Invalid Email or Password"
        
        return render(request, 'login.html', {'error' : error_message})

def logout(request):
    request.session.clear()
    return redirect('login')

class Cart(View):
    @method_decorator(auth_middleware)
    def get(self, request):
        ids = list(request.session.get('cart').keys())
        print(request.session.get('cart'))
        #print(ids)
        cart_products = Product.get_product_in_cart(ids)
        #print("product in cart = ", cart_products)
        return render(request, 'cart.html', {'products':cart_products})


class Checkout(View):
    @method_decorator(auth_middleware)
    def get(self, request):
        print(" I am in Checkout")
        cart = request.session.get('cart')
        #print(cart)
        product_list = list(request.session.get('cart').keys())
        customer = request.session.get("customer")
        #print(customer)
        for id in product_list:
            #print(id)
            product = Product.get_product_in_cart(id)
            #print("this is product under loop",product)
            for pro in product:
                price = pro.price
                product_id = id
                quantity = cart[id]
                #print(price, quantity,product_id)
                order = Order( product = pro, customer = Customer(id = customer), quantity = quantity, price = price)
                order.register()
                request.session.get('cart').clear()
                print("the cart after clearance ",request.session.pop('cart'))
                return render(request, 'order.html')

class Show_order(View):
    @method_decorator(auth_middleware)
    def get(self, request):
        print("This is show order")
        customer = request.session.get("customer")
        orders = Order.get_order_by_customer(customer)
        print(orders)
        order_list = []
        for order in orders:
            product = order.product
            quantity = order.quantity
            price = order.price
            date = order.date
            status = order.status
            total_price = str(int(quantity)*int(price))
            #print(product.name, quantity, price,date,total_price)
            order_list.append({'name':product.name,'quantity':quantity,'price':price,'date':date,'total_price':total_price,'status':status})
        return render(request, 'order.html',{'order_list':order_list})




def homepage(request):
    key_id = 'rzp_live_niCYiMpotHoarE'
    key_secret = 'PAYKIYfoj5V4h9JJZlYjvxJT'
    razorpay_client = razorpay.Client(auth=(key_id, key_secret))
    currency = 'INR'
    amount = 20000 # Rs. 200

    # Create a Razorpay Order
    razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                    currency=currency,
                                                    payment_capture='0'))

    # order id of newly created order.
    razorpay_order_id = razorpay_order['id']
    callback_url = 'paymenthandler/'

    # we need to pass these details to frontend.
    context = {}
    context['razorpay_order_id'] = razorpay_order_id
    context['razorpay_merchant_key'] = key_id
    context['razorpay_amount'] = amount
    context['currency'] = currency
    context['callback_url'] = callback_url

    return render(request, 'payment.html', context=context)


# we need to csrf_exempt this url as
# POST request will be made by Razorpay
# and it won't have the csrf token.
@csrf_exempt
def paymenthandler(request):
    key_id = 'rzp_live_niCYiMpotHoarE'
    key_secret = 'PAYKIYfoj5V4h9JJZlYjvxJT'
    razorpay_client = razorpay.Client(auth=(key_id, key_secret))

    # only accept POST request.
    if request.method == "POST":
        try:
        
            # get the required parameters from post request.
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }

            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result is not None:
                amount = 20000 # Rs. 200
                try:

                    # capture the payemt
                    razorpay_client.payment.capture(payment_id, amount)

                    # render success page on successful caputre of payment
                    return render(request, 'paymentsuccess.html')
                except:

                    # if there is an error while capturing payment.
                    return render(request, 'paymentfail.html')
            else:

                # if signature verification fails.
                return render(request, 'paymentfail.html')
        except:

            # if we don't find the required parameters in POST data
            return HttpResponseBadRequest()
    else:
    # if other than POST request is made.
        return HttpResponseBadRequest()





