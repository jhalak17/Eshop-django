import razorpay

key_id = 'rzp_live_niCYiMpotHoarE'
key_secret = 'PAYKIYfoj5V4h9JJZlYjvxJT'

razorpay_client = razorpay.Client(auth=(key_id, key_secret))


