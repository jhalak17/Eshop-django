from django.contrib import admin
from django.urls import path
from .views import Index , show_signup, Login, logout, Cart, Checkout, Show_order, homepage, paymenthandler

urlpatterns = [
    path('', Index.as_view(), name = 'homepage'),
    path('signup',show_signup),
    path('login',Login.as_view(), name = 'login'),
    path('logout',logout),
    path('cart', Cart.as_view(), name = 'cart'),
    path('checkout', Checkout.as_view(), name = 'checkout'),
    path('orders', Show_order.as_view(), name = 'order'),
    path('payment', homepage, name = 'payment'),
]
